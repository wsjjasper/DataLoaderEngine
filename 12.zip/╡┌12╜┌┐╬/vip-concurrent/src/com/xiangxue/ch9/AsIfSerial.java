package com.xiangxue.ch9;

public class AsIfSerial {
	
	public void calcDist() {
		float v = 35f; //1
		int t = 20;//2
		float s = v*t;//3
	}

}
