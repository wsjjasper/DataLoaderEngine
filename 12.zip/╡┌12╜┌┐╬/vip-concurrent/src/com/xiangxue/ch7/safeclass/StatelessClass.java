package com.xiangxue.ch7.safeclass;

/**
 * 
 *@author Mark老师   享学课堂 https://enjoy.ke.qq.com 
 *
 *类说明：无状态的类，没有任何的成员变量
 */
public class StatelessClass {
	
	public int service(int a,int b) {
		return a*b;
	}
	
	//...public void t(){}

}
